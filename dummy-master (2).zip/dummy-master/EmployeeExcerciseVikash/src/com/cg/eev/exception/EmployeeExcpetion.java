package com.cg.eev.exception;

public class EmployeeExcpetion extends Exception {

	public EmployeeExcpetion() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeExcpetion(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
