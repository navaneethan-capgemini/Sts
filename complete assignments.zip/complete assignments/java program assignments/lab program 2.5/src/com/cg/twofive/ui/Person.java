package com.cg.twofive.ui;

public class Person{
	

		String fname,lname;
		//char gender;
		public Person()
		{}
		public Person(String fname,String lname)
		{
			this.fname=fname;
			this.lname=lname;
			//this.gender=gender;
		}
		public String getfname()
		{
			return fname;
		}
		public void setfname(String fname)
		{
			this.fname=fname;
		}
		public String getlname()
		{
			return lname;
		}
		public void setlname(String lname)
		{
			this.lname=lname;
		}
		enum gender{M,F}
		

	


}
