package com.cg.twofive.ui;



public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person("Nav","suresh");
		
		System.out.println("First Name "+p.getfname());
		System.out.println("last Name "+p.getlname());
		System.out.println("gender "+Person.gender.M);
		

	}

}
