package com.cg.threetwo.ui;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String word=sc.nextLine();
		System.out.println(order(word.toLowerCase()));
		sc.close();
	}
	public static boolean order(String word)
	{
		for(int i=0;i<word.length()-1;i++)
		{
			if(word.charAt(i)>word.charAt(i+1))
				return false;
		}
	
	return true;
}

}
