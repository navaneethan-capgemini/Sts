package com.cg.fourone.ui;

public class Account {
	long accNum;
	double bal;
	Person person;
	public Account()
	{
		
	}
	//@Override
	//public String toString() {
		//return "Account [accNum=" + accNum + ", bal=" + bal + ", person=" + person + "]";
	//}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	public void deposit(double d)
	{
		bal+=d;
	}
	public void withdraw(double d)
	{
		double dd=bal;
		dd-=d;
		if(dd<=500)
		{
			System.out.println("not sufficient balance in account to withdraw");		
		
		}
		else
		{
			bal-=d;
		}
	}
	public double getBalance()
	{
		return bal;
	}
}
