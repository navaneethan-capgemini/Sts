package com.cg.eighthree.ui;


	public class MyMain extends Thread {
	    public static long rand = 0;
	    
		public static void main(String[] args) {

			Thread thread = new Thread();
			rand = (long)(Math.random()*10);
			System.out.println("the number is " +rand);
			new MyMain().start();
		}

		public void run() {
			long fact = 1;
			for(long i= rand; i>1;i--)
			{
				fact= fact*i;
			}
	        System.out.println("The factorial of " +rand + " is : "+fact);
		}

	}



