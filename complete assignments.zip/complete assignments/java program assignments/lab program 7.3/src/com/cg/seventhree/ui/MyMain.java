package com.cg.seventhree.ui;

import java.awt.List;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the elements you to enter");
		int n=sc.nextInt();
		String str1[]=new String[n];
		String str2[]=new String[n];
		System.out.println("Enter String elements one by one for 1St List");
		for(int i=0;i<n;i++)
		{
			String str=sc.next();
			str1[i]=str;
		}
		System.out.println("Enter the string elements one by one for 2nd list");
		for(int i=0;i<n;i++)
		{
			String str=sc.next();
			str2[i]=str;
		}
		
		java.util.List<String> list1=Arrays.asList(str1);
		java.util.List<String> list2=Arrays.asList(str2);
		Set<String> set=removeElements(list1,list2);
		System.out.println("After removal of duplicates "+set);
	}
	private static Set<String> removeElements(java.util.List<String>list1,java.util.List<String>list2)
	{
		Set<String> resultant=new HashSet<String>();
		resultant.addAll(list1);
		resultant.addAll(list2);
		return resultant;
		
		
	}

}
