package com.cg.sixone.ui;

public class Person {

	String fname,lname;
	char gender;
	public Person()
	{}
	public Person(String fname,String lname,char gender)
	{
		this.fname=fname;
		this.lname=lname;
		this.gender=gender;
	}
	public String getfname()
	{
		return fname;
	}
	public void setfname(String fname) throws NameException
	{
		if(fname.isEmpty()) {
			throw new NameException("first name cant be empty\n");
		}
		else
		{
		this.fname=fname;
		}
	}
	public String getlname()
	{
		return lname;
	}
	public void setlname(String lname) throws NameException
	{ 
		if(lname.isEmpty()) {
			throw new NameException("last name cant be empty\n");
		}
		else {
		this.lname=lname;
		}
	}
	public char getgender()
	{
		return gender;
	}
	public void setgender(char gender)
	{
		this.gender=gender;
	}

}
