package com.cg.sixone.ui;

public class NameException extends Exception{

	
	public NameException()
	{
		super();
	}
	public NameException(String msg)
	{
		super(msg);
	}
}
