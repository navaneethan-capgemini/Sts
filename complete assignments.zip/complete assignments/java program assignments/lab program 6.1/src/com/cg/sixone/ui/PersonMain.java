package com.cg.sixone.ui;

import java.util.Scanner;

import javax.naming.NameAlreadyBoundException;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the first name");
		String fname=sc.next();
		System.out.println("Enter the last name");
		String lname=sc.next();
		System.out.println("Enter the gender M/F");
		String gender=sc.next();
		
		
		
		
		Person p=new Person();
		try {
			p.setfname(fname);
		}catch (NameException e)
		{
			System.out.println(e.getMessage());
		}
		try {
			p.setlname(lname);
		}catch (NameException e)
		{
			System.out.println(e.getMessage());
		}
		p.setgender(gender.charAt(0));
		System.out.println("first name "+p.getfname());
		System.out.println("last Name "+p.getlname());
		System.out.println("gender "+p.getgender());
		

	}

}
