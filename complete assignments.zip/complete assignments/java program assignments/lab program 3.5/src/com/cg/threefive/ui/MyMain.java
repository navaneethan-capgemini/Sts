package com.cg.threefive.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String pd;
		int wp;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the purchase date in dd/MM/yyyy");
		pd=sc.nextLine();
		DateTimeFormatter dd=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate ddd1=LocalDate.parse(pd, dd);
		System.out.println("Enter the warranty period in months like 6 months  or 3 months");
		wp=sc.nextInt();
		LocalDate  expirydate=ddd1.plusMonths(wp);
		System.out.println("the expiry date is"+expirydate);
		sc.close();
		

	}

}
