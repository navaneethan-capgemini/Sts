package com.cg.threefour.ui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate today=LocalDate.now();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string in dd/MM/yyyy format");
		String in=sc.nextLine();
		System.out.println("enter the string2 in dd/MM/yyyy format");
		String out=sc.next();
		sc.close();
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate ddd=LocalDate.parse(in,format);
		LocalDate ddd2=LocalDate.parse(out,format);
		Period pp=ddd.until(ddd2);
		
		System.out.println("the current date is"+today);
		System.out.println("the duration is"+pp.getDays()+"days"+pp.getMonths()+"months"+pp.getYears()+"years");

	}

}
