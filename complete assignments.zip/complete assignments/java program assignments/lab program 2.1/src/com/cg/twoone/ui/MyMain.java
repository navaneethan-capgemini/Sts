package com.cg.twoone.ui;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		person p=new person();
		p.printDetails();
	}

}
