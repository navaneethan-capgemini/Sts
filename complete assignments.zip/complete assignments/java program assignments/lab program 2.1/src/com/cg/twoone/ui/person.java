package com.cg.twoone.ui;

public class person {
	String firstname="Nav";
	String lastName="suresh";
	char gender='M';
	int age=21;
	double weight=54;
	
	void printDetails()
	{
		System.out.println("Person details");
		System.out.println("FirstName"+firstname);
		System.out.println("Lastname"+lastName);
		System.out.println("Gender"+gender);
		System.out.println("age"+age);
		System.out.println("weight"+weight);
		
	}

}
