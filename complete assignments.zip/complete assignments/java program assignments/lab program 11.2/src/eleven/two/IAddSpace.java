package eleven.two;
@FunctionalInterface
public interface IAddSpace {
String spaceAdd(String str );
}

