
public class MyMain {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
IFactorial fact=(n)->{
	int result=1;
	for (int i = 1; i <= n; i++) {
		result*=i;
	}
	return result;
};
System.out.println("factorial of a number is: "+fact.factorial(5));
	}

}


