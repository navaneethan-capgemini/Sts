package com.cg.tentwoone.ui;

public class Person {

	private String firstName;
	private String lastName;
	private char G;

	public Person() {
	}

	public char getG() {
		return G;
	}

	public void setG(char g) {
		G = g;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

}
