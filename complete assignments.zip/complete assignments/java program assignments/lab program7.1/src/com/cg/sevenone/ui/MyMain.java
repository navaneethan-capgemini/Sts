package com.cg.sevenone.ui;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the no of elements");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]= new int[n];
		System.out.println("Enter the elements");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		String strArr[]=new String[n];
		for(int i=0;i<n;i++)
		{
			strArr[i]=String.valueOf(arr[i]);
			
		}
		
		
		Integer intArr[]=new Integer[n];
		for(int i=0;i<n;i++)
		{
			StringBuilder s=new StringBuilder(strArr[i]);
			s.reverse();
			intArr[i]=Integer.parseInt(s.toString());
		}
		Arrays.sort(intArr);
		for(int i=0;i<n;i++)
		{
			System.out.println(intArr[i]);
		}
		
		

	}

}
