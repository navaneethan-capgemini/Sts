package eleventhree.ui;

public interface ILogin {
boolean validate(String user,String password);
}

