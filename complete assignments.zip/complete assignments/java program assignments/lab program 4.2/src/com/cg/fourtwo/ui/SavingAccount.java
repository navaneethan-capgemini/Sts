package com.cg.fourtwo.ui;

public class SavingAccount extends Account {
	
	final double minBalance=1000;
	public SavingAccount()
	{
		
	}
	public SavingAccount(String name,double bal,float age)
	{
		this.name=name;
		this.bal=bal;
		this.age=age;
	}
	public void withdraw(double d)
	{
		double bb=bal;
		bb=-d;
		if(bb<=minBalance)
		{
		System.out.println("Not sufficient amount to withdraw");	
		}
		else
		{
			bal=bb;
		}
	}
	@Override
	public String toString() {
		return "SavingAccount [name=" + name + ", bal=" + bal + ", age=" + age + "]";
	}
	
	

}
