package com.cg.fourtwo.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SavingAccount sa=new SavingAccount("nav",10000.0,62);
		CurrentAccount ca=new CurrentAccount("aki",13000,42);
		System.out.println("saving acct");
		System.out.println(sa);
		System.out.println("current Account");
		System.out.println(ca);
		Scanner sc=new Scanner(System.in);
		System.out.println("\n enter amount to withdraw from saving account");
		double withdrawl=sc.nextDouble();
		sa.withdraw(withdrawl);
		
		System.out.println("enter the amount to withdraw from cuurent account");
		double withdraw=sc.nextDouble();
		ca.withdraw(withdraw);
		
		System.out.println("\n after operation account details\n");
		System.out.println(sa);
		System.out.println(ca);
			

	

}
}