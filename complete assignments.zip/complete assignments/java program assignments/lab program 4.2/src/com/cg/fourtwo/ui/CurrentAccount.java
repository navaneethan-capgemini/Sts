package com.cg.fourtwo.ui;

public class CurrentAccount extends Account {
	
	final double overdraft_limit=10000;
	
	public CurrentAccount()
	{
		
	}
	public CurrentAccount(String name,double bal,float age)
	{
		this.name=name;
		this.bal=bal;
		this.age=age;
	}
	
	public void withdraw(double d)
	{
		double bb=bal;
		bb-=d;
		if(bal<=overdraft_limit)
		{
			System.out.println("over_draft limit reached");
		}
		else
		{
			bal=bb;
		}
		
	}
	@Override
	public String toString() {
		return "CurrentAccount [name=" + name + ", bal=" + bal + ", age=" + age + "]";
	}
	

}
