package com.cg.labeightone.ui;

public class MyMain {

	
	public static void main(String[] args) {
		Thread thread = new Thread(new CopyDataThread());
		thread.start();
}
}
