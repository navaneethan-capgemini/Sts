package com.cg.sevenfour.ui;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the elements yow want to enter");
		int n=sc.nextInt();
		System.out.println("Enter the elements one by one");
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			int el=sc.nextInt();
			a[i]=el;
		}
		HashMap<Integer, Integer> map=method(a);
		Iterator<Integer> it=map.keySet().iterator();
		System.out.println("The square of each integer is :");
		while(it.hasNext())
		{
			Integer key=it.next();
			System.out.println(map.get(key));
		}

	}
	
	private static HashMap<Integer, Integer> method(int[] a)
	{
		HashMap<Integer,Integer> map=new HashMap<Integer,Integer>();
		
		for(int n:a)
		{
			map.put(n,n*n);
		}
		return map;
		}
	}


