package com.cg.threeone.ui;

import java.util.*;

public class MyMain {
	static String str;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String string;
		Scanner input=new Scanner(System.in);
		System.out.println("please enter the string");
		string=input.nextLine();
		str=string;
		
		int i=0;
		while(string!=null && i<1)
		{
			menu();
			i++;
		}
		

	}
	
	public static void menu()
	{
		int selection;
		{
			Scanner input=new Scanner(System.in);
			System.out.println("Choose from the menu\n\n");
			System.out.println("1�Add the String to itself");
			System.out.println("2�Replace odd positions with #");
			System.out.println("3�Remove duplicate characters in the String");
			System.out.println("4�Change odd characters to upper case");
			selection=input.nextInt();
			
			
			switch(selection)
			{
			case 1:first();break;
			case 2:second();break;
			case 3:third();break;
			case 4:fourth();break;
			
			
			}
		}
	}
			
			public static void first()
			{
				System.out.println("the resultant string is"+str.concat(str)+"\n");
				menu();
			}
			public static void second()
			
			{
				StringBuilder sb=new StringBuilder(str);
				int counter=0;
				for(int i=0;i<sb.length();i++)
				{
					char currChar=sb.charAt(i);
					if(counter++ %2==1)
					{
						sb.setCharAt(i,'#');
					}
				}
				System.out.println("The resultant string is"+sb.toString()+"\n");
				menu();
				
			}
			public static void third()
			{
				String  newstrr="";
				for(int i=0;i<str.length();i++)
				{
					if(!newstrr.contains(String.valueOf(str.charAt(i))))
					{
						newstrr+=String.valueOf(str.charAt(i));
					}
					
				}
				System.out.println("the resultant string is :"+newstrr+"\n");
				menu();
				
			}
			public static void fourth()
			{
				String newstrr="";
				for(int i=0;i<str.length();i++)
				{
					if(i%2!=0)
					{
						char chh=str.charAt(i);
						newstrr+=String.valueOf(chh).toUpperCase();
					}
					else
					{
						newstrr+=str.charAt(i);
			
					}
				}
				System.out.println("The resultant string is :"+newstrr+"\n");
				menu();
			}
		
						
		
		}	
	
	


