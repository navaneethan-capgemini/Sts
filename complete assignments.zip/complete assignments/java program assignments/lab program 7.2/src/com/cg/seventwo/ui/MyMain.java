package com.cg.seventwo.ui;

import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Pattern;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String str1,str2;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 1st String");
	str1=sc.next();
	System.out.println("Enter 2nd String");
	str2=sc.next();
	performOperation(str1,str2);
	}
	
	private static void performOperation(String str1, String str2)
	{
		List<String> myList=new ArrayList<>();
		int count1=0;
		char c[]=str2.toCharArray();
		StringBuilder myName=new StringBuilder(str1);
		StringBuilder myName2=new StringBuilder(str2);
		for(int i=0;i<str1.length();i++)
		{
			if(i%2==0)
			{
				myName.setCharAt(i, c[count1++]);
			}
		}
		System.out.println("After 1st operation"+myName);
		myList.add(myName.toString());
		str1=myName.toString();
		
		
		int count2=0,idx=0;
		while((idx=str1.indexOf(str2,idx))!=-1)
		{
			idx++;
			count2++;
		}
		if(count2>1)
		{
			int lastindex=str1.indexOf(myName.toString());
			StringBuilder builder=new StringBuilder();
			builder.append(str1.substring(0,lastindex));
			builder.append(myName2.toString());
			builder.append(str1.substring(lastindex)+str2.length());
			str1=builder.toString();
			
			
		}else
		{
			str1=str2;
		}
		System.out.println("After the 2nd operation"+str1);
		myList.add(str1);
		
		int count3=0,idx1=0;
		while((idx1=str1.indexOf(str2,idx1))!=-1)
		{
			idx1++;
			count3++;
	
		}
		if(count3>1)
		{
			str1=str1.replaceFirst(Pattern.quote(str2+""),"");
		}
		myList.add(str1);
		System.out.println("After 3rd operation : "+str1);
		
		String part1,part2;
		part1=str1.substring(0,str2.length()/2);
		part2=str2.substring(str2.length()/2,str2.length());
		str1=part1+str1;
		str1=part1.concat(part2);
		System.out.println("After fourth operation"+str1);
		
		char cv[]=str1.toCharArray();
		char cv1[]=str2.toCharArray();
		for(int j=0;j<cv1.length;j++)
		{
			for(int j2=0;j2<cv.length;j2++)
			{
				if(cv[1]==cv[2])
				{
					cv[j2]='*';
				}
			}
		}
		myList.add(String.valueOf(cv));
		System.out.println("After 5th operation"+String.valueOf(cv));
		System.out.println("\nFinally the arrayList is "+myList);
		
	}

}
