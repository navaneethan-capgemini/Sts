package com.cg.sevenfive.ui;

import java.util.*;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of product names you want to enter");
		int n=sc.nextInt();
		System.out.println("enter the product one by one");
		String array[]=new String[n];
		for(int i=0;i<n;i++)
		{
			String el=sc.next();
		}
		List<String> lis=Arrays.asList(array);
		List<String> finalList=arraysort(array);
		System.out.println("Names after sorting");
		for(String string:finalList)
		{
			System.out.println(string);
		}
	}
		
		private static List<String> arraysort(String[] array)
		{
			List<String> myList=Arrays.asList(array);
			List<String> subList=myList.subList(0,myList.size());
			Collections.sort(subList);
			return subList;
		}

	}


