package com.cg.twotwo.ui;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
			NegerPos n=new NegerPos();
			n.numOne=Integer.parseInt(args[0]);
			n.checknumberType();
		
	}

}
