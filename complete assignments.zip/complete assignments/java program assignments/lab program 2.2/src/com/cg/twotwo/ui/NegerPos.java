package com.cg.twotwo.ui;

public class NegerPos {
	int numOne;

	void checknumberType()
	{
	if(numOne>0)
	{
	System.out.println("number is positive");
	}
	else
	{
	System.out.println("number is negative");

}
	}
}
