package com.cg.eis.ui;
import java.util.*;

import com.cg.eis.service.employeeServiceImpl;

import com.cg.eis.dto.Employee;
public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int ch=0;
		employeeServiceImpl service=new employeeServiceImpl();
				
				do
				{
					printdetails();
					System.out.println("Enter choice");
					Scanner sc=new Scanner(System.in);
					ch=sc.nextInt();
					switch(ch)
					{
					case 1:
					
					Employee emp=new com.cg.eis.dto.Employee();
					//Scanner sc=new Scanner(System.in);
					System.out.println("enter id");
					int eid=sc.nextInt();
					System.out.println("enter the name");
					String ename=sc.next();
					System.out.println("Enter the salary");
					double esal =sc.nextDouble();
					emp.setId(eid);
					emp.setName(ename);
					emp.setSalary(esal);
					//sc.close();
					if(esal>5000 && esal<20000)
					{
						emp.setDesignation("System Associate");
						emp.setInsuranceScheme("Scheme C");
					}
					else if(esal>=20000 && esal<40000)
					{
						emp.setDesignation("programmer");
						emp.setInsuranceScheme("Scheme B");
					}
					else if(esal>=40000)
					{
						emp.setDesignation("Manager");
						emp.setInsuranceScheme("Scheme A");
					}
					else if(esal<5000)
					{
						emp.setDesignation("clerck");
						emp.setInsuranceScheme("no scheme");
					}
					service.addEmployee(emp);
					break;
		
					case 2:
						Set<com.cg.eis.dto.Employee> allData=service.showSortedEmployee();
						for(Employee employee:allData)
						{
							System.out.println("\nId "+employee.getId());
							System.out.println("Name "+employee.getName());
							System.out.println("salary "+employee.getSalary());
							System.out.println("designation "+employee.getDesignation());
							System.out.println("Insurance scheme "+employee.getInsuranceScheme());
							
						}
						break;
					case 3:
						Scanner  s=new Scanner(System.in);
						System.out.println("Enter Employee Insurance scheme(like A/B/C)");
						String scheme=s.next();
						Employee empsearch=service.searchEmployee(scheme);
						if(empsearch==null)
						{
							System.out.println("\nEmployee not found");
						}
						else
						{
							System.out.println("\nId "+empsearch.getId());
							System.out.println("Name "+empsearch.getName());
							System.out.println("salary "+empsearch.getSalary());
							System.out.println("designation "+empsearch.getDesignation());
							System.out.println("Insurance scheme "+empsearch.getInsuranceScheme());
						}
						break;
					case 4:
						System.out.println("enter employee ID");
						int eidd=sc.nextInt();
						service.deleteEmployee(eidd);
						break;
					case 5:
						System.out.println("Thanks for using....");
						System.exit(0);
						break;
					default:
						break;
					}
				}while(ch!=5);
					
						
	}
				public static void printdetails()
				{
					System.out.println("1.Add employee \n2.sort Employee \n3.Search Employee\n4.delete employee");
				}

}
