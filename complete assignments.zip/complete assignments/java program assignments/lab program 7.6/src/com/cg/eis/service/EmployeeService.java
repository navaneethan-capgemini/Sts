package com.cg.eis.service;

import java.util.*;

import com.cg.eis.dto.Employee;

public interface EmployeeService {
	
	public abstract void addEmployee(Employee emp);
	public Set<Employee> showSortedEmployee();
	public void deleteEmployee(int id);
	public Employee searchEmployee(String scheme);
	
	

}
