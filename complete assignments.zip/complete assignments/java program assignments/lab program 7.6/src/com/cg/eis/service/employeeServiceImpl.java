package com.cg.eis.service;

import java.util.HashMap;
import java.util.Set;
import java.util.TreeSet;

import com.cg.eis.dto.Employee;

public class employeeServiceImpl implements EmployeeService {

	HashMap<Integer, Employee> list=new HashMap<Integer,Employee>();
	Set<Employee> myList=new TreeSet<>();
	int key=1;
	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		System.out.println("\nEmployee added suucessfully\n");
		myList.add(emp);
		list.put(key++, emp);
		
		
	}
	
	
	@Override
	public void deleteEmployee(int eid) {
		// TODO Auto-generated method stub
		Set<Integer> keys=list.keySet();
		for(Integer integer:keys)
		{
			if(eid==integer)
			{
				list.remove(eid);
			}
		}
		int found=0;
		for(Employee productDtoLayer:myList)
		{
			myList.remove(productDtoLayer);
			found=1;
			break;
		}		
	
	
	if(found==1)
	{
		System.out.println("employee id with"+eid+"is succesfully removed");
	}
	else
	{
		System.out.println("no employee found");
	}
	}

	@Override
	public Set<Employee> showSortedEmployee() {
		// TODO Auto-generated method stub
		return myList;
		
	}

	

	@Override
	public Employee searchEmployee (String scheme) {
		// TODO Auto-generated method stub
		Employee psearch=null;
		for(Employee productDtoLayer:myList)
		{
			if(productDtoLayer.getInsuranceScheme().trim()==scheme.trim())
			{
				psearch=productDtoLayer;
				break;
			}
		}
		
		return psearch;
	}
	

}

