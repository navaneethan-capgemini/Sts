package eleven.one;



	public interface ICalculation {
		public void power(int a,int b);
	}


