package com.cg.nineone.ui;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(new File("input.txt")).useDelimiter("\\z");
		String contents=sc.next();
		
		System.out.println("original contents is"+contents);
		
		contents=new StringBuilder(contents).reverse().toString();
		
		System.out.println("reversed contents is"+contents);
		
		FileWriter fwt=new FileWriter("out.txt");
		BufferedWriter br=new BufferedWriter(fwt);
		br.write(contents);
		br.close();
		sc.close();

	}

}
