package com.cg.threethree.ui;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate today=LocalDate.now();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string in dd/MM/yyyy format");
		String in=sc.nextLine();
		sc.close();
		DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate ddd=LocalDate.parse(in,format);
		Period pp=ddd.until(today);
		
		System.out.println("the current date is"+today);
		System.out.println("the duration is"+pp.getDays()+"days"+pp.getMonths()+"months"+pp.getYears()+"years");
		
		

	}

}
