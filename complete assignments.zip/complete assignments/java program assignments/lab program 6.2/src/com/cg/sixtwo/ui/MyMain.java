package com.cg.sixtwo.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		SavingAccount sa=new SavingAccount();
		CurrentAccount ca=new CurrentAccount();
		System.out.println("enter details for saving acct");
		System.out.println("Enter the Name");
		String sname=sc.next();
		System.out.println("Enter the balance");
		double sbal=sc.nextDouble();
		System.out.println("Enter the age");
		float age=sc.nextFloat();
		//System.out.println(ca);
		//Scanner sc=new Scanner(System.in);
		System.out.println("enter amount to withdraw from saving account");
		double withdrawl=sc.nextDouble();
		sa.setName(sname);
		sa.setBal(sbal);
		
		try
		
		{
			sa.setAge(age);
		}catch(AgeException e)
		{
			System.out.println(e.getMessage());
		}
		sa.withdraw(withdrawl);
		System.out.println("enter details for current acct");
		System.out.println("Enter the Name");
		String cname=sc.next();
		System.out.println("Enter the balance");
		double cbal=sc.nextDouble();
		System.out.println("Enter the age");
		float cage=sc.nextFloat();
		//System.out.println(ca);
		//Scanner sc=new Scanner(System.in);
		System.out.println("enter the amount to withdraw from cuurent account");
		double withdraw=sc.nextDouble();
		//ca.withdraw(withdraw);
		ca.setName(cname);
		ca.setBal(cbal);
		
		try
		{
			ca.setAge(cage);
		}catch(AgeException e)
		{
			System.out.println(e.getMessage());
		}
		
		ca.withdraw(withdraw);
		System.out.println("After operation account details");
		System.out.println("saving acount \nName "+sa.getName()+"\nage "+sa.getAge()+"\nbalance "+sa.getBal());
		System.out.println("current account \nName "+ca.getName()+"\nage "+ca.getAge()+"\nbalance "+ca.getBal()); 
			

	

}
}