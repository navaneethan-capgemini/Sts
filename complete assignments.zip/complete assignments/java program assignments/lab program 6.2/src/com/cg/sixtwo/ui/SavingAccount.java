package com.cg.sixtwo.ui;

public class SavingAccount extends Account {
	
	final double minBalance=1000;
	
	public void withdraw(double d)
	{
		double bb=bal;
		bb-=d;
		if(bb<=minBalance)
		{
		System.out.println("Not sufficient amount to withdraw");	
		}
		else
		{
			bal=bb;
		}
	}

	@Override
	public String toString() {
		return "SavingAccount [minBalance=" + minBalance + ", name=" + name + ", bal=" + bal + ", age=" + age + "]";
	}
	
	
}