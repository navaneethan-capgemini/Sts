package com.cg.sixtwo.ui;

public class CurrentAccount extends Account {
	
	final double overdraft_limit=10000;
	
	
	public void withdraw(double d)
	{
		double bb=bal;
		bb-=d;
		if(bal>=overdraft_limit)
		{
			System.out.println("over_draft limit reached");
		}
		else
		{
			bal=bb;
		}
		
		
	}


	
	
	

	
	}
