package com.cg.sixtwo.ui;

public class AgeException extends Exception{
	
	public AgeException()
	{
		super();
	}
	public AgeException(String msg)
	{
		super(msg);
	}

}
