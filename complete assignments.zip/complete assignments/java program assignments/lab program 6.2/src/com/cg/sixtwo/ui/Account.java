package com.cg.sixtwo.ui;

public class Account {

	String name;
	double bal;
	float age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getBal() {
		return bal;
	}
	public void setBal(double bal) {
		this.bal = bal;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) throws AgeException {
		if(age<15)
		{
			throw new AgeException("\n age should be greater than 15");
		}
		else {
		this.age = age;
		}
	}
	
}
