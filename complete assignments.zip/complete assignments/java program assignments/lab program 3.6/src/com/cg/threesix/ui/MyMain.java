package com.cg.threesix.ui;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String zid;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter zones like America/New_York, Europe/London, Asia/Tokyo, US/Pacific, Africa/Cairo, Australia/Sydney etc");
		zid=sc.nextLine();
		ZonedDateTime dt=ZonedDateTime.now(ZoneId.of(zid));
		System.out.println("The current date and time of the timezone in"+dt);
		
		
		
		

	}

}
