package com.cg.eis.service;

public interface EmployeeService {
	
	public abstract void showDetails();

}
