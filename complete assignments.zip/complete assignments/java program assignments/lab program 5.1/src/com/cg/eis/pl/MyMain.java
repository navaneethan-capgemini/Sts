package com.cg.eis.pl;
import java.util.*;

import com.cg.eis.bean.Employee;
public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter the name");
		String name=sc.next();
		System.out.println("Enter the salary");
		double salary =sc.nextDouble();
		emp.setId(id);
		emp.setName(name);
		emp.setSalary(salary);
		sc.close();
		if(salary>5000 && salary<20000)
		{
			emp.setDesignation("System Associate");
			emp.setInsuranceScheme("Scheme C");
		}
		else if(salary>=20000 && salary<40000)
		{
			emp.setDesignation("programmer");
			emp.setInsuranceScheme("Scheme B");
		}
		else if(salary>=40000)
		{
			emp.setDesignation("Manager");
			emp.setInsuranceScheme("Scheme A");
		}
		else if(salary<5000)
		{
			emp.setDesignation("clerck");
			emp.setInsuranceScheme("no scheme");
		}
		emp.showDetails();
	}

}
