package com.cg.threeseven.ui;
import java.util.*;

public class MyMain {
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		String str;
		System.out.println("Enter aan applicant name ending with _job like abc_job");
		str=sc.nextLine();
		if(str.length()>=12)
		{
		if(str.substring(str.length()-4, str.length()).equalsIgnoreCase("_job"))
		{
			System.out.println("true");
			
		}
		else
		{
			System.out.println("false");
		}
		}
		else
		{
			System.out.println("false");
		}

}
	
}
