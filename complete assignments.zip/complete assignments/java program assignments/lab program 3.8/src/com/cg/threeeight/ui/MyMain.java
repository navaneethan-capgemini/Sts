package com.cg.threeeight.ui;

import java.util.Scanner;

public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		String temp;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the  nos of string");
		//str=sc.nextLine();
		int n=sc.nextInt();
		System.out.println("Enter the string one by one");
		String arr[]=new String[n];
		for(int i=0;i<n;i++)
		{
			String s=sc.next();
			arr[i]=s;
		}
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i].compareTo(arr[j])>0)
				{
					temp=arr[i];
					arr[i]=arr[j];
					arr[j]=temp;
				}
			}
		}
		for(String str1:arr)
		{
			if(arr.length%2==0)
			{
				for(int i=0;i<arr.length/2;i++)
				{
					arr[i]=arr[i].toUpperCase();
				}
			}
			else
			{
				for(int i=0;i<arr.length/2+1;i++)
				{
					arr[i]=arr[i].toUpperCase();
				}
			}
		}
		System.out.println("name after sorting");
		for(String str1:arr)
		{
			System.out.println(str1);
		}
	}

}
