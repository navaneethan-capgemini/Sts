package com.cg.fivethree.ui;



public abstract class Account {
		long accNum;
		double bal;
		Person person;
		public Account()
		{
			
		}
		//@Override
		//public String toString() {
			//return "Account [accNum=" + accNum + ", bal=" + bal + ", person=" + person + "]";
		//}
		public long getAccNum() {
			return accNum;
		}
		public void setAccNum(long accNum) {
			this.accNum = accNum;
		}
		public double getBal() {
			return bal;
		}
		public void setBal(double bal) {
			this.bal = bal;
		}
		public Person getPerson() {
			return person;
		}
		public void setPerson(Person person) {
			this.person = person;
		}
		public abstract void deposit(double d);
		public abstract void withdraw(double d);
		public double getBalance()
		{
			return bal;
		}
	}



