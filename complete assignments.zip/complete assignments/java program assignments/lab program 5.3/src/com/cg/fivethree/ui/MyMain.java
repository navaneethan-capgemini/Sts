package com.cg.fivethree.ui;

import java.util.Scanner;



public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
long accno=(long) ((Math.random()*((100000-10000)+1))+10000);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter acct holder name");
		String name=sc.next();
		System.out.println("enter acct holder Age");
		float age=sc.nextFloat();
		System.out.println("enter amount to deposit");
		double deposit=sc.nextDouble();
		System.out.println("enter amount to withdraw");
		double withdraw=sc.nextDouble();
		
		Person person=new Person();
		person.setName(name);
		person.setAge(age);
		
		Account account=new AccountInh();
		account.setAccNum(accno);
		account.setPerson(person);
		account.deposit(deposit);
		account.withdraw(withdraw);
		
		System.out.println("the account details \nthe account name holder : "+account.getPerson().getName()+"\nage is : "+account.getPerson().getAge()+"\nAccount number is : "+account.getAccNum()+"\nbalance remaining is : "+account.getBalance());


	}

}
