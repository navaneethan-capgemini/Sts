package com.cg.fivethree.ui;

public class AccountInh extends Account{

	@Override
	public void deposit(double d) {
		// TODO Auto-generated method stub
		bal+=d;
		
	}

	@Override
	public void withdraw(double d) {
		// TODO Auto-generated method stub
		
		double dd=bal;
		dd-=d;
		if(dd<=500)
		{
			System.out.println("not sufficient balance in account to withdraw");		
		
		}
		else
		{
			bal-=d;
		}
		
	}
	
	
	

}
