package com.cg.twofour.ui;



public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person("Nav","suresh",'M');
		System.out.println("First Name "+p.getfname());
		System.out.println("last Name "+p.getlname());
		System.out.println("gender "+p.getgender());
		int a=Integer.parseInt(args[0]);
		System.out.println("phone no"+a);

	}

}
