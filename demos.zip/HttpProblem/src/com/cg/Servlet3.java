package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet3")
public class Servlet3 extends HttpServlet {
	
	PrintWriter out=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		out=response.getWriter();
		  HttpSession s1=request.getSession();
		  System.out.println("in serv 3"+s1);
		
		String n=(String)s1.getAttribute("name");
		String c=(String)s1.getAttribute("cityName");
		String m=(String)s1.getAttribute("mob");	  
		/*String n=(String)request.getAttribute("name");
		String c=(String)request.getAttribute("cityName");
		String m=(String)request.getAttribute("mob");
		String courseList[]=(String[])request.getAttribute("course");
		*/
		out.println("<h1> name : "+n+"</h1>");
		out.println("<h1> city : "+c+"</h1>");
		out.println("<h1> Mobile : "+m+"</h1>");
		out.println("<a href='Servlet4'>servlet 4</a>");
	
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
