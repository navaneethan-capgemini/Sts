package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.Customer;

public class CustomerDaoImpl implements ICustomerDao
{
	ArrayList<Customer> custList=new ArrayList<>();
	public boolean addCustomer(Customer cust) 
	{
		// dao // arraylist
		
		boolean status=custList.add(cust);
		System.out.println(custList);
		
		return status;
		
	}
	public ArrayList<Customer>viewAllCustomer(){
		
		
		return custList;
		
	}
	
}
